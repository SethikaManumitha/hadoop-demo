#!/bin/bash

# Create directory and set permissions for Spark event logs
mkdir -p /tmp/spark-events
chmod 777 /tmp/spark-events